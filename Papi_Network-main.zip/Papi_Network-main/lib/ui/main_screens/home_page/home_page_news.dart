import 'package:flutter/material.dart';
import 'package:papi_network/ui/main_screens/home_page/news_screen1.dart';
import 'package:papi_network/widgets/bollet_title.dart';

import '../../../constants/app_colors.dart';

class HomePageNews extends StatefulWidget {
  const HomePageNews({Key? key}) : super(key: key);

  @override
  State<HomePageNews> createState() => _HomePageNewsState();
}

class _HomePageNewsState extends State<HomePageNews> {
  List headings = [
    'New Headline 1',
    'New Headline 2',
    'New Headline 3',
    'New Headline 4',
    'New Headline 5',
  ];

  List dates = [
    '29 March 2023',
    '26 March 2023',
    '21 March 2023',
    '16 March 2023',
    '12 March 2023',
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 18.0, top: 5),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                BulletTitle(title: 'News'),
              ],
            ),
            SizedBox(
              child: ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: headings.length,
                itemBuilder: (BuildContext context, int index) {
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => NewsScreen1()));
                    },
                    child: Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 11,
                          ),
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.horizontal(
                                  left: Radius.circular(10),
                                  right: Radius.circular(10),
                                )),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  height: 75,
                                  width: 85,
                                  decoration: BoxDecoration(
                                      color: AppColors.yellow,
                                      borderRadius: BorderRadius.horizontal(
                                          left: Radius.circular(10))),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        'New',
                                        style: TextStyle(fontSize: 8),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        'Post',
                                        style: TextStyle(fontSize: 8),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        'Image',
                                        style: TextStyle(fontSize: 8),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 8,
                                ),
                                Expanded(
                                  child: Container(
                                    height: 70,
                                    width: 240,
                                    padding: EdgeInsets.all(11),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          headings[index],
                                          style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                              dates[index],
                                              style: TextStyle(fontSize: 8),
                                            ),
                                            Spacer(),
                                            Icon(
                                              Icons.favorite_border,
                                              size: 12,
                                            ),
                                            Text(
                                              '6.4k',
                                              style: TextStyle(fontSize: 8),
                                            ),
                                            SizedBox(
                                              width: 11,
                                            ),
                                            Icon(
                                              Icons.share_outlined,
                                              size: 12,
                                            ),
                                            SizedBox(
                                              width: 11,
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
