import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';

import '../constants/app_urls.dart';
import '../utils/utils.dart';

class AuthProvider with ChangeNotifier {
  /// for loading
  bool _loading = false;
  bool get loading => _loading;
  setLoading(bool value) {
    _loading = value;
    notifyListeners();
  }

  /// for Password Visibility
  bool _passwordVisibility = true;
  bool get passwordVisibility => _passwordVisibility;
  setPasswordVisibility(bool value) {
    _passwordVisibility = value;
    notifyListeners();
  }

  /// Register Function
  void register(
    context, {
    required String email,
    required String password,
    required String name,
  }) async {
    setLoading(true);

    try {
      Response response = await post(
        Uri.parse('$baseUrl/register/user'),
        body: {
          'email': email,
          'password': password,
          'name': name,
        },
      );
      if (response.statusCode == 200) {
        setLoading(false);
        // Navigator.push(
        //     context, MaterialPageRoute(builder: (context) => OTPScreen()));
        debugPrint('account created successfully');
        Utils.flutterToast('account created successfully');
      } else {
        setLoading(false);
        debugPrint('Failed');
        Utils.flutterToast('Failed');
      }
    } catch (e) {
      setLoading(false);
      debugPrint(e.toString());
      Utils.flutterToast(e.toString());
    }
  }

  /// Login With Email Function
  void loginWithEmail(
    context, {
    required String email,
    required String password,
    // required String name,
  }) async {
    setLoading(true);

    try {
      Response response = await post(
        Uri.parse('$baseUrl/login/user'),
        body: {
          'email': email,
          'password': password,
          // 'name': name,
        },
      );
      if (response.statusCode == 200) {
        setLoading(false);

        var data = jsonDecode(response.body.toString());
        debugPrint(data.toString());
        // Navigator.push(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) => BottomNavigationBarForApp()));
        debugPrint('login successfully');
        Utils.flutterToast('Login successfully');
      } else {
        setLoading(false);
        debugPrint('Failed');
        Utils.flutterToast('Failed');
      }
    } catch (e) {
      setLoading(false);
      debugPrint(e.toString());
      Utils.flutterToast(e.toString());
    }
  }
}
