package com.example.papinetwork.papi_network;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
